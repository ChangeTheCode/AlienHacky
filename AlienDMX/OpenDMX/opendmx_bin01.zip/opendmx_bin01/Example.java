package com.juanjo.OpenDmx.BasicExample;

import com.juanjo.openDmx.OpenDmx;

public class Main {

	public static void main(String[] args) {


		//open dmx widget for send data
		if(!OpenDmx.connect(OpenDmx.OPENDMX_TX)){
			System.err.println("Error opening Open Dmx widget!");
			return;
		}
		
		
		//change dmx values
		for(int i=0;i<512;i++){
			OpenDmx.setValue(i,(int)(Math.random()*255));
		}

		//close dmx widget
		OpenDmx.disconnect();
		
	}

}
