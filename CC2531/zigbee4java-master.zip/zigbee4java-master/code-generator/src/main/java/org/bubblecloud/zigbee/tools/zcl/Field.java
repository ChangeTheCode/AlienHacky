package org.bubblecloud.zigbee.tools.zcl;

/**
 * Created by tlaukkan on 4/10/2016.
 */
public class Field {
    public int fieldId;
    public String fieldLabel;
    public String fieldType;
    public String dataType;
    public String dataTypeClass;
    public String nameUpperCamelCase;
    public String nameLowerCamelCase;
}
