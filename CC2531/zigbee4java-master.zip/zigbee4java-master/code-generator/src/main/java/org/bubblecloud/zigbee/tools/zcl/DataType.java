package org.bubblecloud.zigbee.tools.zcl;

/**
 * Created by tlaukkan on 4/10/2016.
 */
public class DataType {
    public String dataTypeName;
    public String dataTypeType;
    public String dataTypeClass;
}
