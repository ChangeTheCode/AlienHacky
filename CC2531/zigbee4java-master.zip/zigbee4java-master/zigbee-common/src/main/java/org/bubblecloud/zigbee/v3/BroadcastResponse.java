package org.bubblecloud.zigbee.v3;

/**
 * Broadcast response.
 */
public class BroadcastResponse extends Command {

}
