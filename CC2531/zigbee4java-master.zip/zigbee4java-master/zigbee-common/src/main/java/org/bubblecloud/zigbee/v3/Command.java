package org.bubblecloud.zigbee.v3;

/**
 * Common base class for commands.
 */
public class Command {

}
