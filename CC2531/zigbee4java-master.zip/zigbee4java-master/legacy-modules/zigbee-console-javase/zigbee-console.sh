#!/bin/sh
java -jar target/zigbee-console-javase-3.0.0-SNAPSHOT.jar /dev/cu.usbmodem1411 11 4952 false
