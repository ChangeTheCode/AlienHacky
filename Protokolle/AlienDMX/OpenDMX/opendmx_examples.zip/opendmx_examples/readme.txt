Add VM arguments (for opendmx.dll)

-Djava.library.path=dll

