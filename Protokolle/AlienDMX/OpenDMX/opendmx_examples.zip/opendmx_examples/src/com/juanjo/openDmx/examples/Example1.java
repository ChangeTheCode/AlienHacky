package com.juanjo.openDmx.examples;

import java.io.IOException;

import com.juanjo.openDmx.OpenDmx;

/**
 * @author juanjo
 *
 * send random data to 512 dmx channels every 1 second
 */
public class Example1 {

	public static final int MAX_CHANNELS = 512;
	
	public static void main(String[] args) {
		
		//open send mode
		if(!OpenDmx.connect(OpenDmx.OPENDMX_TX)){
			System.out.println("Open Dmx widget not detected!");
			return;
		}
		
		//while no input key
		try {
			while(System.in.available()==0){
				
				//fill all dmx channels
				for(int i=0;i<MAX_CHANNELS;i++){					
					//random value to channel
					OpenDmx.setValue(i,(int)(Math.random()*255));					
				}
				
				//wait 1 second
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//close
		OpenDmx.disconnect();
	}

}
