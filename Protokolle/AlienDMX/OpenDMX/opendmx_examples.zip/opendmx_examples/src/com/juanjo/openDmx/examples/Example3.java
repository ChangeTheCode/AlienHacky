package com.juanjo.openDmx.examples;

import com.juanjo.openDmx.OpenDmx;

public class Example3 {

	public static final int MAX_CHANNELS = 512;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//open receive mode
		if(!OpenDmx.connect(OpenDmx.OPENDMX_RX)){
			System.out.println("Open Dmx widget not detected!");
			return;
		}
		
		System.out.println("Dmx received values:");
		
		//dump dmx values
		int v;
		for(int i=0;i<MAX_CHANNELS;i++){
			v=OpenDmx.getValue(i);
			System.out.print(String.valueOf(i)+"="+String.valueOf(v)+", ");
		}
		
		//close
		OpenDmx.disconnect();
	}

}
